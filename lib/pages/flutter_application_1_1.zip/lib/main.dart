import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(
        title: Text(
          '흡연구역지정',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          Expanded(
              flex: 1,
              child: Container(
                color: Colors.grey[300],
              )),
          Expanded(
              flex: 8,
              child: Container(
                color: Colors.grey[100],
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(30),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 100,
                            child: FlutterLogo(size: 800),
                          ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            '사진 입력',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ),
                    Flexible(
                        child: Container(
                      child: Column(children: [
                        Image.network('src'),
                        SizedBox(
                          height: 15,
                        ),
                        Text('"환풍구",     "재떨이",      "10명 이상 수용 가능"'),
                        Text('확인')
                      ]),
                    ))
                  ],
                ),
              ))
        ],
      ),
    ));
  }
}
